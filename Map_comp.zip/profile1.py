longueur=200
hauteur=100
aff="non"
html="oui"
fic="rien"
nomhtml="export.html"
