#device = "iPad"
#import dialogs

device = "PC"
