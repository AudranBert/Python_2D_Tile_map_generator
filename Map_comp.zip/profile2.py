longueur=5
hauteur=5
aff="oui"
html="oui"
fic="rien"
nomhtml="export.html"
